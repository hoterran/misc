/*@A (C) 1992 Allen I. Holub                                                */
main()
{
    statements();
}
