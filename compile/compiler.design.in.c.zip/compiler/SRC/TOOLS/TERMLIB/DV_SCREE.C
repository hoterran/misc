/*@A (C) 1992 Allen I. Holub                                                */
#define ALLOC
#include "video.h"

/* This file has no code in it. It just allocates space for the variables
 * defined in video.h
 */
