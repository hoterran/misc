/*@A (C) 1992 Allen I. Holub                                                */
#include <tools/debug.h>
#ifdef __TURBOC__
#pragma argsused	/* Turn off "tos not used" warning under Turbo C */
#endif
void yy_init_llama( tos ) void *tos; { }
