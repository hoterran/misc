/*@A (C) 1992 Allen I. Holub                                                */
void yyhook_b(){}		/* entered with a ^B command */
