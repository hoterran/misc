/*@A (C) 1992 Allen I. Holub                                                */
void yy_init_lex( ) {}  /* Default initialization routine--does nothing. */
