/*@A (C) 1992 Allen I. Holub                                                */
void yyhook_a(){}		/* entered with a ^A command */
