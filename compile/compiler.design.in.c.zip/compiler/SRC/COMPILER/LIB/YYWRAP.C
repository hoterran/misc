/*@A (C) 1992 Allen I. Holub                                                */
int	yywrap()	 /* yylex() halts if 1 is returned */
{
    return( 1 );
}
