extern void print_grammar(void);
extern void print_vec(const char *m, struct vector v);
extern void print_stack(const char *s);
