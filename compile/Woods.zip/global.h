extern char input[];
extern char start;
extern void grammar(void);
extern void rule(char lhs, char *rhs, char *context);
