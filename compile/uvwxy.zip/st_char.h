struct st_char	{
	char ch;
	char marker;
};

