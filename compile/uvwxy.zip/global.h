#define	STACKSIZE	100
#define	TEXTSIZE	100

extern char start;
extern void grammar(void);
extern void rule(char lhs, const char rhs[]);
