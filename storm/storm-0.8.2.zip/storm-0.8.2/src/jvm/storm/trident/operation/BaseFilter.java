package storm.trident.operation;


public abstract class BaseFilter extends BaseOperation implements Filter {
    
}
