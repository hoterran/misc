package storm.trident.operation;


public abstract class BaseAggregator<T> extends BaseOperation implements Aggregator<T> {
    
}
