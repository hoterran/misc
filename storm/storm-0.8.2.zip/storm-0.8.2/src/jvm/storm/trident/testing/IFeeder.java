package storm.trident.testing;


public interface IFeeder {
    void feed(Object tuples);        
}
