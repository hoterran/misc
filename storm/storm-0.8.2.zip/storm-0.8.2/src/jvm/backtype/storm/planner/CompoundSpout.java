package backtype.storm.planner;


public class CompoundSpout
        //implements ISpout
{

}